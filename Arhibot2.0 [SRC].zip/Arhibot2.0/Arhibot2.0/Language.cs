﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Arhibot2._0
{
    public partial class Language : Form
    {
        public Language()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(comboBox1.Text == "English (Default)")
            {
                Program.lang = "en";
                this.Hide();
                var warning = new Form1();
                warning.Show();
                this.Close();
            }
            else if (comboBox1.Text == "Russian")
            {
                Program.lang = "ru";
                this.Hide();
                var warning = new Form1();
                warning.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("You tried to edit a Combobox value. Вы пытались изменить значение выпадающего списка.\nPlease, choose a choice from combobox! Пожалуйста, выберите вариант из списка!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void Language_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
