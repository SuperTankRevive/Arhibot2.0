﻿
namespace Arhibot2._0
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.timer6 = new System.Windows.Forms.Timer(this.components);
            this.timer7 = new System.Windows.Forms.Timer(this.components);
            this.timer8 = new System.Windows.Forms.Timer(this.components);
            this.timer9 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer10 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.msgbox = new System.Windows.Forms.Timer(this.components);
            this.gdi1 = new System.Windows.Forms.Timer(this.components);
            this.gdi2 = new System.Windows.Forms.Timer(this.components);
            this.gdi3 = new System.Windows.Forms.Timer(this.components);
            this.spam = new System.Windows.Forms.Timer(this.components);
            this.gdi4 = new System.Windows.Forms.Timer(this.components);
            this.gdi5 = new System.Windows.Forms.Timer(this.components);
            this.gdi6 = new System.Windows.Forms.Timer(this.components);
            this.msgbox2 = new System.Windows.Forms.Timer(this.components);
            this.black_screen = new System.Windows.Forms.Timer(this.components);
            this.last_msg = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 9000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 15000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer5
            // 
            this.timer5.Interval = 15000;
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // timer6
            // 
            this.timer6.Interval = 12000;
            this.timer6.Tick += new System.EventHandler(this.timer6_Tick);
            // 
            // timer7
            // 
            this.timer7.Interval = 10000;
            this.timer7.Tick += new System.EventHandler(this.timer7_Tick);
            // 
            // timer8
            // 
            this.timer8.Interval = 40000;
            this.timer8.Tick += new System.EventHandler(this.timer8_Tick);
            // 
            // timer9
            // 
            this.timer9.Interval = 15000;
            this.timer9.Tick += new System.EventHandler(this.timer9_Tick);
            // 
            // timer4
            // 
            this.timer4.Interval = 17000;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // timer10
            // 
            this.timer10.Interval = 60000;
            this.timer10.Tick += new System.EventHandler(this.timer10_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 10000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // msgbox
            // 
            this.msgbox.Tick += new System.EventHandler(this.msgbox_Tick);
            // 
            // gdi1
            // 
            this.gdi1.Tick += new System.EventHandler(this.gdi1_Tick);
            // 
            // gdi2
            // 
            this.gdi2.Tick += new System.EventHandler(this.gdi2_Tick);
            // 
            // gdi3
            // 
            this.gdi3.Tick += new System.EventHandler(this.gdi3_Tick);
            // 
            // spam
            // 
            this.spam.Interval = 150;
            this.spam.Tick += new System.EventHandler(this.spam_Tick);
            // 
            // gdi4
            // 
            this.gdi4.Tick += new System.EventHandler(this.gdi4_Tick);
            // 
            // gdi5
            // 
            this.gdi5.Tick += new System.EventHandler(this.gdi5_Tick);
            // 
            // gdi6
            // 
            this.gdi6.Tick += new System.EventHandler(this.gdi6_Tick);
            // 
            // msgbox2
            // 
            this.msgbox2.Interval = 50000;
            this.msgbox2.Tick += new System.EventHandler(this.msgbox2_Tick);
            // 
            // black_screen
            // 
            this.black_screen.Tick += new System.EventHandler(this.black_screen_Tick);
            // 
            // last_msg
            // 
            this.last_msg.Tick += new System.EventHandler(this.last_msg_Tick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(347, 231);
            this.ControlBox = false;
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.Opacity = 0D;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Arhibot";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.Timer timer7;
        private System.Windows.Forms.Timer timer8;
        private System.Windows.Forms.Timer timer9;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer10;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer msgbox;
        private System.Windows.Forms.Timer gdi1;
        private System.Windows.Forms.Timer gdi2;
        private System.Windows.Forms.Timer gdi3;
        private System.Windows.Forms.Timer spam;
        private System.Windows.Forms.Timer gdi4;
        private System.Windows.Forms.Timer gdi5;
        private System.Windows.Forms.Timer gdi6;
        private System.Windows.Forms.Timer msgbox2;
        private System.Windows.Forms.Timer black_screen;
        private System.Windows.Forms.Timer last_msg;
    }
}