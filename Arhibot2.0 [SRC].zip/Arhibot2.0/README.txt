' Arhibot2.0.exe [SRC]
' by Super Tank (arhibot)
' Last Edited: 02.08.2023 / Source Code Publish Data: 27.03.2024
' Remember, that creators are not responsible for damages, using this software.

// RUS:
' Arhibot2.0.exe [ИСХОДНЫЙ КОД]
' от Super Tank (arhibot)
' Последне редактирование: 02.08.2023 / Дата публикации исходного кода: 27.03.2024
' Помните, что разработчики не несут ответственности за повреждения, используя этим инструментом.

